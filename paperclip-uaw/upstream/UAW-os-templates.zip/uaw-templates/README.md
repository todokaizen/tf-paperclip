# UAW-os Project Templates

## Setup

To initialize a new project under the Universal Agentic Workflow, copy this folder into your project root:

```
cp -r uaw-templates/ your-project/uaw/
```

Your project will have:

```
your-project/
  uaw/
    resume.md          ← current state — the one file to read on return
    decisions.md       ← append-only architectural decisions
    specs/             ← spec files for non-exploratory work
      spec-template.md ← copy and rename per spec
    archive/           ← dated resume.md copies from prior sessions
    README.md          ← this file
```

## Linear Setup

Configure your Linear project with these statuses in order:

1. IDEA
2. SPEC
3. TODO
4. IN PROGRESS
5. BLOCKED
6. REVIEW
7. DONE

## First Run

1. Open `resume.md` and fill in the Project State section (project name, phase, objective)
2. Delete the placeholder text in each field
3. The agent will maintain both files from this point forward

## Agent Read Order

On every session start, the agent reads:

1. `resume.md`
2. `decisions.md`
3. Active spec (if referenced in resume)
4. Linear for new issues or priority changes

## Session End

On every session end, the agent:

1. Updates Linear with current task state
2. Copies `resume.md` to `archive/resume-YYYY-MM-DD.md`
3. Writes fresh `resume.md` with current state
4. Updates `decisions.md` if any decisions were made
